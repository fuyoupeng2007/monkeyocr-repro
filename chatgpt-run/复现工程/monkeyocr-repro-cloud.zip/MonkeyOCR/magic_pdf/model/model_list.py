class AtomicModel:
    Layout = "layout"
